import { useState } from "react";

type Pyodide = {
  runPythonAsync: (code: string) => Promise<unknown>;
  setStdout: (o: { batched: (s: string) => void }) => void;
  setStderr: (o: { batched: (s: string) => void }) => void;
};

declare global {
  interface Window {
    loadPyodide?: (opts?: { indexURL?: string }) => Promise<Pyodide>;
  }
}

const VERSION = "0.26.4";
let pyodidePromise: Promise<Pyodide> | null = null;

function getPyodide() {
  if (!pyodidePromise) {
    pyodidePromise = new Promise<Pyodide>((resolve, reject) => {
      const start = () =>
        window.loadPyodide!({ indexURL: `https://cdn.jsdelivr.net/pyodide/v${VERSION}/full/` }).then(resolve, reject);
      if (window.loadPyodide) { start(); return; }
      const s = document.createElement("script");
      s.src = `https://cdn.jsdelivr.net/pyodide/v${VERSION}/full/pyodide.js`;
      s.onload = start;
      s.onerror = () => reject(new Error("Could not load Python"));
      document.head.appendChild(s);
    });
    pyodidePromise.catch(() => (pyodidePromise = null));
  }
  return pyodidePromise;
}

export function PythonPlayground({ initial }: { initial: string }) {
  const [code, setCode] = useState(initial);
  const [out, setOut] = useState("Press RUN to see the result.");
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    setOut("Loading Python... (first time can take a few seconds)");
    try {
      const py = await getPyodide();
      const lines: string[] = [];
      py.setStdout({ batched: (s) => lines.push(s) });
      py.setStderr({ batched: (s) => lines.push(s) });
      await py.runPythonAsync(code);
      setOut(lines.join("\n") || "(no output)");
    } catch (e) {
      setOut(String(e instanceof Error ? e.message : e));
    }
    setBusy(false);
  }

  return (
    <div className="card-pop mt-6 overflow-hidden bg-card">
      <div className="flex items-center justify-between border-b-2 border-foreground bg-foreground px-4 py-2 text-background">
        <span className="font-mono text-xs">python playground</span>
        <button onClick={run} disabled={busy} className="rounded bg-secondary px-4 py-1 text-sm font-bold text-secondary-foreground disabled:opacity-50">
          {busy ? "RUNNING..." : "RUN ▶"}
        </button>
      </div>
      <textarea value={code} onChange={(e) => setCode(e.target.value)} spellCheck={false} rows={Math.min(code.split("\n").length + 1, 20)} className="w-full bg-card p-4 font-mono text-sm outline-none" />
      <pre className="max-h-64 overflow-auto whitespace-pre-wrap border-t-2 border-foreground bg-muted p-4 font-mono text-sm">{out}</pre>
    </div>
  );
}
