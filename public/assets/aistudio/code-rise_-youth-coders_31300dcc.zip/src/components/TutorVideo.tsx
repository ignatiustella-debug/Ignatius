import { useEffect, useRef, useState } from "react";

// A "video lesson" that runs entirely on the phone: an animated tutor
// narrates each slide with the device voice, so it works offline.
export function TutorVideo({ title, slides }: { title: string; slides: string[] }) {
  const all = [`Hi! I'm Rise, your tutor. Today's lesson: ${title}.`, ...slides, "Great job! Now try the quiz and the task below. You can do it!"];
  const [i, setI] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [talking, setTalking] = useState(false);
  const playRef = useRef(false);

  useEffect(() => () => { playRef.current = false; window.speechSynthesis?.cancel(); }, []);

  function say(idx: number) {
    const s = window.speechSynthesis;
    if (!s || idx >= all.length) { setPlaying(false); playRef.current = false; setTalking(false); return; }
    setI(idx);
    const u = new SpeechSynthesisUtterance((all[idx] ?? "").replace(/[`*#<>]/g, " "));
    u.lang = "en-GB";
    u.rate = 0.95;
    u.onstart = () => setTalking(true);
    u.onend = () => { setTalking(false); if (playRef.current) setTimeout(() => say(idx + 1), 500); };
    s.speak(u);
  }
  function play() {
    window.speechSynthesis?.cancel();
    playRef.current = true;
    setPlaying(true);
    say(i >= all.length - 1 ? 0 : i);
  }
  function pause() {
    playRef.current = false;
    setPlaying(false);
    setTalking(false);
    window.speechSynthesis?.cancel();
  }
  function go(n: number) {
    pause();
    setI(Math.max(0, Math.min(all.length - 1, n)));
  }

  return (
    <div className="card-pop mt-6 overflow-hidden bg-card">
      <div className="flex items-center justify-between border-b-2 border-foreground bg-foreground px-4 py-2 text-background">
        <span className="font-mono text-xs">🎬 video lesson · works offline</span>
        <span className="font-mono text-xs">{i + 1}/{all.length}</span>
      </div>
      <div className="grid items-center gap-4 bg-muted p-5 sm:grid-cols-[auto_1fr]">
        <div className={`relative mx-auto h-32 w-32 rounded-full border-4 border-foreground bg-primary ${talking ? "animate-bounce" : ""}`} style={{ animationDuration: "1.2s" }}>
          <span className="absolute left-8 top-10 h-4 w-4 rounded-full bg-foreground" />
          <span className="absolute right-8 top-10 h-4 w-4 rounded-full bg-foreground" />
          <span className={`absolute left-1/2 top-[4.6rem] w-10 -translate-x-1/2 rounded-full bg-foreground transition-all ${talking ? "h-5 animate-pulse" : "h-1.5"}`} />
          <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-md border-2 border-foreground bg-secondary px-2 font-mono text-xs">{"</>"}</span>
        </div>
        <div className="card-pop min-h-28 bg-card p-4">
          <p className="text-lg font-semibold">{all[i]}</p>
        </div>
      </div>
      <div className="h-2 bg-background"><div className="h-full bg-primary transition-all" style={{ width: `${((i + 1) / all.length) * 100}%` }} /></div>
      <div className="flex flex-wrap justify-center gap-3 p-3">
        <button onClick={() => go(i - 1)} className="rounded-md border-2 border-foreground bg-muted px-3 py-2 font-semibold">⏮</button>
        {playing ? (
          <button onClick={pause} className="rounded-md bg-primary px-6 py-2 font-bold text-primary-foreground">⏸ Pause</button>
        ) : (
          <button onClick={play} className="rounded-md bg-primary px-6 py-2 font-bold text-primary-foreground">▶ Play lesson</button>
        )}
        <button onClick={() => go(i + 1)} className="rounded-md border-2 border-foreground bg-muted px-3 py-2 font-semibold">⏭</button>
      </div>
    </div>
  );
}
