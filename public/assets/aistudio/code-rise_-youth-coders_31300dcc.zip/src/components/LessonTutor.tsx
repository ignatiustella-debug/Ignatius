import { useState } from "react";
import { askTutor } from "@/lib/tutor.functions";

type Msg = { role: "user" | "assistant"; content: string };

export function LessonTutor({ lesson }: { lesson: string }) {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [voice, setVoice] = useState(true);
  const [listening, setListening] = useState(false);

  function speak(t: string) {
    if (!voice || typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(t.replace(/[`*#<>]/g, " "));
    u.lang = "en-GB";
    window.speechSynthesis.speak(u);
  }

  function listen() {
    const w = window as unknown as { SpeechRecognition?: new () => any; webkitSpeechRecognition?: new () => any };
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) { alert("Voice input is not supported on this browser. Try Chrome."); return; }
    const r = new SR();
    r.lang = "en-NG";
    r.onresult = (e: any) => setText(e.results[0][0].transcript);
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    setListening(true);
    r.start();
  }

  async function send() {
    const q = text.trim();
    if (!q || busy) return;
    const next: Msg[] = [...msgs, { role: "user", content: q }];
    setMsgs(next);
    setText("");
    setBusy(true);
    if (!navigator.onLine) {
      setMsgs([...next, { role: "assistant", content: "I need internet to answer new questions. You can still read and listen to the lesson offline." }]);
      setBusy(false);
      return;
    }
    try {
      const r = await askTutor({ data: { lesson, messages: next } });
      setMsgs([...next, { role: "assistant", content: r.reply }]);
      speak(r.reply);
    } catch {
      setMsgs([...next, { role: "assistant", content: "Sorry, I couldn't answer. Try again." }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className="card-pop fixed bottom-5 right-5 z-40 bg-accent px-5 py-3 font-semibold text-accent-foreground"
      >
        {open ? "Close tutor" : "🤖 Ask the tutor"}
      </button>
      {open && (
        <div className="card-pop fixed bottom-20 right-3 z-40 flex h-[70vh] w-[calc(100vw-1.5rem)] max-w-sm flex-col bg-card">
          <div className="border-b-2 border-foreground bg-accent p-3 text-accent-foreground">
            <p className="font-display font-bold">Rise — your lesson tutor</p>
            <p className="text-xs">Stuck? Type or tap 🎤 to talk.</p>
            <button onClick={() => { setVoice(!voice); window.speechSynthesis?.cancel(); }} className="mt-1 text-xs underline">{voice ? "🔊 Voice on" : "🔇 Voice off"}</button>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto p-3 text-sm">
            {msgs.length === 0 && (
              <div className="space-y-2">
                {["Explain this lesson more simply", "Give me a hint for the task", "Show me another example"].map((s) => (
                  <button key={s} onClick={() => setText(s)} className="block w-full rounded-md border-2 border-foreground bg-muted p-2 text-left">{s}</button>
                ))}
              </div>
            )}
            {msgs.map((m, i) => (
              <div key={i} className={`whitespace-pre-wrap rounded-md p-2 ${m.role === "user" ? "ml-8 bg-primary text-primary-foreground" : "mr-4 bg-muted"}`}>{m.content}</div>
            ))}
            {busy && <p className="text-muted-foreground">Thinking...</p>}
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2 border-t-2 border-foreground p-2">
            <button type="button" onClick={listen} aria-label="Talk" className={`rounded-md border-2 border-foreground px-2 ${listening ? "bg-secondary" : "bg-muted"}`}>🎤</button>
            <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type your question..." className="flex-1 rounded-md border-2 border-foreground bg-background px-2 py-2 text-sm" />
            <button disabled={busy} className="rounded-md bg-primary px-3 font-semibold text-primary-foreground">Send</button>
          </form>
        </div>
      )}
    </>
  );
}
