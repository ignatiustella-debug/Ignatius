import { Link } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";
import { useProgress } from "@/lib/progress";
import { levels } from "@/lib/lessons";
import { LessonTutor } from "@/components/LessonTutor";
import { Certificate } from "@/components/Certificate";

const info = {
  2: {
    title: "Build & Sell",
    tag: "Freelancer track",
    emoji: "🛠️",
    blurb: "Each lesson gives you a real website template you can sell to local businesses.",
    lockedText: "Submit your Level 1 final project (Lesson 5) to unlock Level 2.",
    unlockLesson: "5",
    cert: "CodeRise Level 2 Graduate - Freelancer",
    band: "bg-accent text-accent-foreground",
    chip: "bg-secondary",
  },
  3: {
    title: "From Naira to Dollars",
    tag: "Dollar earner track",
    emoji: "🚀",
    blurb: "Python and dollar freelancing for serious students who finished Level 2.",
    lockedText: "Submit your Level 2 final task (Lesson 10) to unlock Level 3.",
    unlockLesson: "10",
    cert: "CodeRise Level 3 Graduate - Dollar Earner",
    band: "bg-primary text-primary-foreground",
    chip: "bg-accent text-accent-foreground",
  },
} as const;

export function LevelPage({ level }: { level: 2 | 3 }) {
  const { user, ready } = useAuth();
  const { data } = useProgress(user?.id);
  const meta = info[level];
  const unlocked = level === 2 ? !!data?.level2 : !!data?.level3;
  const graduated = level === 2 ? !!data?.level3 : !!data?.graduated;
  const lessons = levels[level];
  const done = lessons.filter((l) => data?.completed.has(l.id)).length;

  return (
    <main className="min-h-screen">
      <section className={`border-b-2 border-foreground ${meta.band}`}>
        <div className="mx-auto max-w-5xl px-5 pb-12 pt-8">
          <Link to="/learn" className="font-mono text-sm underline">{"< All levels"}</Link>
          <div className="mt-8 flex flex-wrap items-end justify-between gap-6">
            <div>
              <span className={`card-pop inline-block px-3 py-1 font-mono text-xs uppercase text-foreground ${meta.chip}`}>Level {level} · {meta.tag}</span>
              <h1 className="mt-4 text-5xl font-bold md:text-7xl">{meta.emoji} {meta.title}</h1>
              <p className="mt-3 max-w-xl text-lg opacity-90">{meta.blurb}</p>
            </div>
            {unlocked && (
              <div className="card-pop bg-card p-4 text-card-foreground">
                <p className="font-mono text-xs uppercase">Progress</p>
                <p className="font-display text-4xl font-bold">{done}/{lessons.length}</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-5xl px-5 py-10">
        {!ready ? null : !unlocked ? (
          <div className="card-pop mx-auto max-w-xl bg-muted p-8 text-center">
            <p className="text-5xl">🔒</p>
            <p className="mt-3 text-2xl font-bold">Locked</p>
            <p className="mt-2">{meta.lockedText}</p>
            <Link
              to={user ? "/learn/$lessonId" : "/auth"}
              params={{ lessonId: meta.unlockLesson }}
              className="card-pop mt-5 inline-block bg-primary px-5 py-3 font-semibold text-primary-foreground"
            >
              {user ? `Go to Lesson ${meta.unlockLesson}` : "Sign in to start"}
            </Link>
          </div>
        ) : (
          <>
            {graduated && (
              <div className="card-pop mb-8 bg-secondary p-6 text-center">
                <p className="text-4xl">🎉</p>
                <p className="mt-2 font-display text-3xl font-bold">You finished Level {level}!</p>
                <p className="mt-1">Your certificate is ready below — save it and share it.</p>
              </div>
            )}
            <div className="grid gap-5 sm:grid-cols-2">
              {lessons.map((l, i) => {
                const isDone = data?.completed.has(l.id);
                return (
                  <Link
                    key={l.id}
                    to="/learn/$lessonId"
                    params={{ lessonId: l.id }}
                    className={`card-pop group relative flex flex-col overflow-hidden bg-card p-6 transition-transform hover:-translate-y-1 ${i === lessons.length - 1 ? "sm:col-span-2" : ""}`}
                  >
                    <span className="pointer-events-none absolute -right-2 -top-6 font-display text-8xl font-bold text-muted">{l.id}</span>
                    <span className="relative font-mono text-xs uppercase text-accent">{isDone ? "✓ Done" : `Lesson ${l.id}`}</span>
                    <span className="relative mt-2 font-display text-xl font-bold">{l.title}</span>
                    <span className="relative mt-2 text-sm text-muted-foreground">{l.objective}</span>
                    {l.price && <span className={`card-pop relative mt-4 self-start px-3 py-1 text-sm font-semibold ${meta.chip}`}>Sell for {l.price}</span>}
                  </Link>
                );
              })}
            </div>
            {graduated && <Certificate level={level} title={meta.cert} />}
            {level === 3 && graduated && (
              <div className="card-pop mt-8 bg-accent p-6 text-accent-foreground">
                <p className="font-mono text-xs uppercase">Bonus · Free class</p>
                <p className="mt-1 font-display text-2xl font-bold">🎁 Build apps with Lovable</p>
                <p className="mt-2">A free gift for finishing every level: learn to build full apps just by describing them.</p>
                <Link to="/bonus" className="card-pop mt-4 inline-block bg-card px-5 py-3 font-semibold text-card-foreground">Start the free class →</Link>
              </div>
            )}
          </>
        )}
      </div>
      <LessonTutor lesson={`Level ${level}: ${meta.title}. ${meta.blurb} Lessons: ${lessons.map((l) => l.title).join("; ")}`} />
    </main>
  );
}
