import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/hooks/useAuth";

function css(v: string) {
  return getComputedStyle(document.documentElement).getPropertyValue(v).trim() || "#222";
}

export function Certificate({ level, title }: { level: 1 | 2 | 3; title: string }) {
  const { user } = useAuth();
  const ref = useRef<HTMLCanvasElement>(null);
  const meta = (user?.user_metadata ?? {}) as { full_name?: string; name?: string };
  const [name, setName] = useState(meta.full_name || meta.name || user?.email?.split("@")[0] || "");

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    const W = 1600, H = 1130;
    c.width = W; c.height = H;
    const bg = css("--background"), fg = css("--foreground"), pr = css("--primary"), ac = css("--accent"), se = css("--secondary");
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = pr; ctx.fillRect(0, 0, W, 30); ctx.fillRect(0, H - 30, W, 30);
    ctx.strokeStyle = fg; ctx.lineWidth = 8; ctx.strokeRect(60, 60, W - 120, H - 120);
    ctx.strokeStyle = ac; ctx.lineWidth = 3; ctx.strokeRect(85, 85, W - 170, H - 170);
    ctx.textAlign = "center";
    ctx.fillStyle = fg; ctx.font = "bold 64px 'Space Grotesk', sans-serif";
    ctx.fillText("Code", W / 2 - 70, 220);
    ctx.fillStyle = pr; ctx.fillText("Rise", W / 2 + 85, 220);
    ctx.fillStyle = ac; ctx.font = "500 30px 'JetBrains Mono', monospace";
    ctx.fillText("CERTIFICATE OF COMPLETION", W / 2, 300);
    ctx.fillStyle = fg; ctx.font = "28px 'DM Sans', sans-serif";
    ctx.fillText("This certifies that", W / 2, 400);
    ctx.font = "bold 96px 'Space Grotesk', sans-serif";
    ctx.fillText(name || "Your Name", W / 2, 520);
    ctx.fillStyle = pr; ctx.fillRect(W / 2 - 350, 550, 700, 6);
    ctx.fillStyle = fg; ctx.font = "28px 'DM Sans', sans-serif";
    ctx.fillText(`has completed Level ${level} and is now a`, W / 2, 640);
    ctx.font = "bold 52px 'Space Grotesk', sans-serif";
    ctx.fillText(title, W / 2, 720);
    ctx.fillStyle = se; ctx.beginPath(); ctx.arc(W / 2, 880, 90, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = fg; ctx.lineWidth = 5; ctx.stroke();
    ctx.fillStyle = fg; ctx.font = "bold 40px 'JetBrains Mono', monospace";
    ctx.fillText(`L${level}`, W / 2, 895);
    ctx.font = "24px 'DM Sans', sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" }), 180, 960);
    ctx.textAlign = "right";
    ctx.fillText("code-bloom-kids.lovable.app", W - 180, 960);
  }, [name, level, title]);

  function blob(): Promise<Blob | null> {
    return new Promise((r) => ref.current!.toBlob(r, "image/png"));
  }
  async function download() {
    const b = await blob(); if (!b) return;
    const a = document.createElement("a");
    a.href = URL.createObjectURL(b); a.download = `CodeRise-Level-${level}-Certificate.png`; a.click();
  }
  async function share() {
    const b = await blob(); if (!b) return;
    const file = new File([b], `CodeRise-Level-${level}.png`, { type: "image/png" });
    const text = `I just completed Level ${level} on Code Rise and I'm now a ${title}! 🎓`;
    if (navigator.canShare?.({ files: [file] })) {
      try { await navigator.share({ files: [file], text, title: "My Code Rise certificate" }); } catch { /* cancelled */ }
    } else {
      window.open(`https://wa.me/?text=${encodeURIComponent(text + " " + window.location.origin)}`, "_blank");
    }
  }

  return (
    <div className="card-pop mt-8 bg-card p-5">
      <p className="font-mono text-xs uppercase text-accent">Your certificate</p>
      <p className="mt-1 font-display text-2xl font-bold">🎓 {title}</p>
      <label className="mt-4 block text-sm font-semibold">Name on certificate</label>
      <input value={name} onChange={(e) => setName(e.target.value.slice(0, 40))} className="mt-1 w-full rounded-md border-2 border-foreground bg-background px-3 py-2" />
      <canvas ref={ref} className="mt-4 w-full rounded-md border-2 border-foreground" />
      <div className="mt-4 flex flex-wrap gap-3">
        <button onClick={download} className="card-pop bg-primary px-5 py-3 font-semibold text-primary-foreground">⬇ Save certificate</button>
        <button onClick={share} className="card-pop bg-secondary px-5 py-3 font-semibold">📤 Share</button>
      </div>
    </div>
  );
}
