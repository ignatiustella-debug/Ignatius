import { useEffect, useState, useCallback } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

const GOOGLE_USER_KEY = "coderise_google_user";
const AUTH_EVENT = "coderise_auth_change";

export function getStoredGoogleUser(): User | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(GOOGLE_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);

  const syncUser = useCallback(async () => {
    // 1. Check Supabase session
    try {
      const { data } = await supabase.auth.getSession();
      if (data?.session?.user) {
        setUser(data.session.user);
        setReady(true);
        return;
      }
    } catch {
      // Continue to local Google session
    }

    // 2. Check local Google session
    const googleUser = getStoredGoogleUser();
    setUser(googleUser);
    setReady(true);
  }, []);

  useEffect(() => {
    syncUser();

    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session?.user) {
        setUser(session.user);
      } else {
        const googleUser = getStoredGoogleUser();
        setUser(googleUser);
      }
      setReady(true);
    });

    const handleCustomAuth = () => {
      syncUser();
    };

    window.addEventListener(AUTH_EVENT, handleCustomAuth);

    return () => {
      sub.subscription.unsubscribe();
      window.removeEventListener(AUTH_EVENT, handleCustomAuth);
    };
  }, [syncUser]);

  const loginWithGoogle = useCallback((email = "ignatiustella@gmail.com", name = "Ignatius Stella") => {
    const cleanEmail = email.trim() || "ignatiustella@gmail.com";
    const cleanName = name.trim() || cleanEmail.split("@")[0] || "Learner";

    let hash = 0;
    for (let i = 0; i < cleanEmail.length; i++) {
      hash = ((hash << 5) - hash) + cleanEmail.charCodeAt(i);
      hash |= 0;
    }
    const hex = Math.abs(hash).toString(16).padStart(8, "0");
    const id = `00000000-0000-4000-8000-${hex.padEnd(12, "0").slice(0, 12)}`;

    const googleUser: User = {
      id,
      aud: "authenticated",
      role: "authenticated",
      email: cleanEmail,
      email_confirmed_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      app_metadata: {
        provider: "google",
        providers: ["google"],
      },
      user_metadata: {
        full_name: cleanName,
        name: cleanName,
        email: cleanEmail,
        avatar_url: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(cleanName)}&backgroundColor=f26b1d`,
      },
    };

    localStorage.setItem(GOOGLE_USER_KEY, JSON.stringify(googleUser));
    setUser(googleUser);
    window.dispatchEvent(new Event(AUTH_EVENT));
    return googleUser;
  }, []);

  const logout = useCallback(async () => {
    localStorage.removeItem(GOOGLE_USER_KEY);
    try {
      await supabase.auth.signOut();
    } catch {
      // ignore
    }
    setUser(null);
    window.dispatchEvent(new Event(AUTH_EVENT));
  }, []);

  return { user, ready, loginWithGoogle, logout };
}
