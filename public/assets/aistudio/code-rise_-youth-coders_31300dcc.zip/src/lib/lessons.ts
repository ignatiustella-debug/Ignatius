export type Quiz = { question: string; options: string[]; answer: number };
export type Lesson = {
  id: string;
  title: string;
  objective: string;
  pidgin: string;
  points?: string[];
  code?: string;
  note?: { label: string; text: string };
  quiz?: Quiz;
  tasks: { label: string; text: string; list?: string[] }[];
};

export const level1: Lesson[] = [
  {
    id: "1",
    title: "What is Coding? Your Ticket Out",
    objective: "Understand why coding can end poverty.",
    pidgin:
      "Coding is how you tell a computer what to do, just like giving someone instructions. If you master it, international companies can pay you in dollars, even while you live in Diobu.",
    points: [
      "A computer is not smart on its own. It only does what you tell it.",
      "Coding is a language, like English, but for computers.",
      "With coding, you can build websites for shops in GRA and get paid N30k - N100k.",
    ],
    quiz: { question: "What is coding?", options: ["Telling computer what to do", "Cooking food"], answer: 0 },
    tasks: [{ label: "Task", text: 'Write your dream - "I want to learn coding to..."' }],
  },
  {
    id: "2",
    title: "How Internet & Websites Work",
    objective: "How a website goes from your phone to the world.",
    pidgin:
      "You know how you send a WhatsApp message? A website works the same way. Your code lives in a house (a server), and anyone anywhere can open it.",
    points: [
      "Frontend = What you see (the face)",
      "Backend = What works in the background (the brain)",
      "We will start with Frontend - HTML, CSS, JS.",
    ],
    note: { label: "Code Example", text: "Open your browser, right click > Inspect, and look at the code." },
    quiz: { question: "Frontend is what you see?", options: ["True", "False"], answer: 0 },
    tasks: [],
  },
  {
    id: "3",
    title: "HTML - The Skeleton of Website [FIRST CODE]",
    objective: "Build your first web page.",
    pidgin: "HTML is the skeleton, like the blocks used to build a house. Without it, the house cannot stand.",
    code: `<h1>I Am a Future Billionaire</h1>
<p>My name is Chinedu from Port Harcourt.</p>
<button>Hire Me</button>`,
    note: { label: "How to run", text: "Type this in the code editor and press RUN." },
    quiz: { question: "Which tag is for big heading?", options: ["<h1>", "<p>"], answer: 0 },
    tasks: [{ label: "Project", text: "Make your own personal profile page with your name, skill, and location." }],
  },
  {
    id: "4",
    title: "CSS - Make It Beautiful!",
    objective: "Add color and style.",
    pidgin: "If HTML is the skeleton, CSS is the clothes and paint. That is why some websites look better than others.",
    code: `<style>
  h1 { color: green; background: black; padding: 20px; }
  p { color: blue; font-size: 20px; }
  button { background: orange; padding: 15px; border: none; }
</style>

<h1>I Am a Future Billionaire</h1>
<p>My name is Chinedu from Port Harcourt.</p>
<button>Hire Me</button>`,
    tasks: [
      { label: "Project", text: "Style your Lesson 3 page. Make your name green, add orange button like Jumia." },
      { label: "Challenge", text: "Make a flyer for a barbing salon in Trans-Amadi." },
    ],
  },
  {
    id: "5",
    title: "JavaScript - Make It Work",
    objective: "Make your website do things when clicked.",
    pidgin: "JavaScript is the magic. It makes a website respond when you click on it.",
    code: `<button onclick="alert('You have hired me! Call 080...')">Hire Me Now</button>

<button onclick="showPrice()">See Price</button>

<script>
  function showPrice() {
    alert("I will build website for N20,000");
  }
</script>`,
    tasks: [
      {
        label: "Final Project for Level 1",
        text: 'Build "My Business Card Website". Must have:',
        list: [
          "Your name",
          "What you can do (e.g. I can build small websites)",
          "A working button that shows your WhatsApp number when clicked.",
        ],
      },
      { label: "Next Level Unlock", text: "Once you submit this, you enter Level 2." },
    ],
  },
];

export type TemplateLesson = Lesson & { sellTo?: string; price?: string; template?: string; templateName?: string; python?: string };

const posTemplate = `<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Chukwu POS</title>
<style>
  body { font-family: Arial, sans-serif; margin: 0; background: #f4fff4; color: #111; }
  .box { text-align: center; padding: 20px; border: 2px solid green; margin: 20px; border-radius: 12px; background: white; }
  ul { list-style: none; padding: 0; }
  li { padding: 8px; border-bottom: 1px solid #ddd; }
  button, .wa { display: inline-block; background: green; color: white; border: none; padding: 12px 20px; border-radius: 8px; font-size: 16px; text-decoration: none; margin-top: 10px; }
  iframe { width: 100%; height: 220px; border: 0; border-radius: 8px; }
</style>
</head>
<body>
<div class="box">
  <h2>CHUKWU POS - 24 Hours</h2>
  <p>Charges: N100 for N5k</p>
  <ul>
    <li>Cash Withdrawal</li>
    <li>Transfer</li>
    <li>Airtime & Data</li>
  </ul>
  <p id="status"></p>
  <button onclick="document.getElementById('status').innerText='We are OPEN now!'">Check if Open</button>
  <br>
  <a class="wa" href="https://wa.me/2348012345678">Chat on WhatsApp</a>
</div>
<div class="box">
  <h3>Find Us</h3>
  <iframe src="https://maps.google.com/maps?q=Diobu,Port%20Harcourt&output=embed"></iframe>
</div>
</body>
</html>`;

const foodTemplate = `<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mama Put Kitchen</title>
<style>
  body { font-family: Arial, sans-serif; margin: 0; background: #fff8ef; }
  header { background: #e65100; color: white; text-align: center; padding: 24px; }
  .menu { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; padding: 16px; }
  .food-card { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 6px rgba(0,0,0,.15); text-align: center; padding-bottom: 12px; }
  .food-card img { width: 100%; height: 120px; object-fit: cover; }
  button { background: #25d366; color: white; border: none; padding: 10px 16px; border-radius: 8px; font-weight: bold; }
</style>
</head>
<body>
<header><h1>Mama Put Kitchen</h1><p>Hot food, fast delivery</p></header>
<div class="menu">
  <div class="food-card">
    <img src="https://images.unsplash.com/photo-1604329760661-e71dc83f8f26?w=400" alt="Jollof rice">
    <h3>Jollof + Chicken - N2,500</h3>
    <button onclick="order('Jollof + Chicken')">Order Now</button>
  </div>
  <div class="food-card">
    <img src="https://images.unsplash.com/photo-1547592180-85f173990554?w=400" alt="Soup">
    <h3>Afang Soup - N3,000</h3>
    <button onclick="order('Afang Soup')">Order Now</button>
  </div>
  <div class="food-card">
    <img src="https://images.unsplash.com/photo-1561651823-34feb02250e4?w=400" alt="Shawarma">
    <h3>Shawarma - N2,000</h3>
    <button onclick="order('Shawarma')">Order Now</button>
  </div>
</div>
<script>
function order(food) {
  window.open("https://wa.me/2348012345678?text=" + encodeURIComponent("I want to order " + food));
}
</script>
</body>
</html>`;

const styles = [
  ["Agbada Set", "N45,000", "1593030761757-71fae45fa0e7"],
  ["Ankara Gown", "N25,000", "1515372039744-b8f02a3ae446"],
  ["Senator Wear", "N30,000", "1617137968427-85924c800a22"],
  ["Wedding Dress", "N120,000", "1594552072238-b8a33785b261"],
  ["Kaftan", "N20,000", "1617127365659-c47fa864d8bc"],
  ["Office Skirt Suit", "N35,000", "1594633312681-425c7b97ccd1"],
];

const tailorTemplate = `<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ada Couture - Port Harcourt</title>
<style>
  body { font-family: Georgia, serif; margin: 0; background: #faf7f2; color: #222; }
  header { text-align: center; padding: 30px 16px; background: #222; color: #f5d78e; }
  .gallery { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 8px; padding: 8px; }
  .item { position: relative; cursor: pointer; }
  .item img { width: 100%; aspect-ratio: 1; object-fit: cover; display: block; }
  .item span { position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,.6); color: white; padding: 6px; font-size: 14px; }
  #lightbox { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.9); align-items: center; justify-content: center; flex-direction: column; color: white; }
  #lightbox img { max-width: 90%; max-height: 75vh; }
  form { max-width: 400px; margin: 20px auto; padding: 16px; background: white; border-radius: 12px; }
  input, button { width: 100%; padding: 12px; margin-top: 8px; box-sizing: border-box; font-size: 16px; }
  button { background: #222; color: #f5d78e; border: none; border-radius: 8px; }
</style>
</head>
<body>
<header><h1>Ada Couture</h1><p>Custom fashion, Port Harcourt</p></header>
<div class="gallery">
${styles.map(([n, p, id]) => `  <div class="item" onclick="openBox(this)"><img src="https://images.unsplash.com/photo-${id}?w=500" alt="${n}"><span>${n} - ${p}</span></div>`).join("\n")}
</div>
<div id="lightbox" onclick="this.style.display='none'"><img id="big"><p id="cap"></p><p>Tap to close</p></div>
<form onsubmit="book(event)">
  <h2>Book a Measurement</h2>
  <input id="name" placeholder="Your name" required>
  <input id="date" type="date" required>
  <button>Book on WhatsApp</button>
</form>
<script>
function openBox(el) {
  document.getElementById('big').src = el.querySelector('img').src;
  document.getElementById('cap').innerText = el.querySelector('span').innerText;
  document.getElementById('lightbox').style.display = 'flex';
}
function book(e) {
  e.preventDefault();
  var msg = "Hello, my name is " + document.getElementById('name').value + ". I want to book a measurement for " + document.getElementById('date').value;
  window.open("https://wa.me/2348012345678?text=" + encodeURIComponent(msg));
}
</script>
</body>
</html>`;

const salonTemplate = `<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Glory Hair Salon</title>
<style>
  body { font-family: Arial, sans-serif; margin: 0; }
  header { background: #8e24aa; color: white; text-align: center; padding: 40px 16px; }
  section { padding: 20px; text-align: center; }
  .wa { display: inline-block; background: #25d366; color: white; padding: 14px 24px; border-radius: 30px; text-decoration: none; font-weight: bold; }
</style>
</head>
<body>
<header><h1>GLORY HAIR SALON - Rumuola</h1><p>We make you look beautiful</p></header>
<section><h2>Our Services</h2><p>Braids - Weaving - Retouching - Makeup</p></section>
<section><h2>What Customers Say</h2><p>"Best braids in Port Harcourt!" - Blessing</p></section>
<section><a class="wa" href="https://wa.me/2348012345678">Chat Us on WhatsApp</a></section>
</body>
</html>`;

export const level2: TemplateLesson[] = [
  {
    id: "6",
    title: "The N20k Business Website Formula",
    objective: "Learn the 4 sections every small business website needs.",
    pidgin:
      "Every shop in Mile 1 and every salon in GRA needs these 4 things on their website. Once you know them, you can charge for it.",
    points: [
      "Hero - Big business name + what you do",
      "Services - What you sell",
      "Proof - Customer reviews and photos",
      "Contact - A WhatsApp button (the most important part for Nigerian customers)",
    ],
    templateName: "Salon Starter",
    price: "N20,000",
    template: salonTemplate,
    tasks: [{ label: "Project", text: "Clone this template for any business on your street. Paste your code below." }],
  },
  {
    id: "7",
    title: "Project 1 - POS / Provision Store Website",
    objective: "Build a website you can sell to POS and provision stores.",
    pidgin: "Every POS and provision store needs to be found online. This simple site puts them on the map.",
    sellTo: "POS operators and provision stores in Diobu",
    price: "N15,000",
    points: [
      "Store name",
      "List of services: Withdrawal, Transfer, Airtime",
      'Live status: "We are OPEN"',
      "Google Map location",
      "WhatsApp button",
    ],
    note: {
      label: "How to sell",
      text: 'Take a screenshot and visit 5 POS shops today. Tell them: "I will put your shop on Google so customers can find you."',
    },
    templateName: "POS Store",
    template: posTemplate,
    tasks: [{ label: "Project", text: "Customise this template for a real POS or provision store. Paste your code below." }],
  },
  {
    id: "8",
    title: "Project 2 - Restaurant / Food Vendor Website",
    objective: "Build a food menu where customers order on WhatsApp.",
    pidgin: "Mama Put, shawarma spots and soup sellers all need a menu customers can order from with one tap.",
    sellTo: "Mama Put, shawarma spots, Afang soup sellers",
    price: "N25,000",
    points: ["Food menu with pictures", "Prices for each meal", "Order on WhatsApp button", "Key skill: CSS Grid for the menu layout"],
    templateName: "Food Menu",
    template: foodTemplate,
    tasks: [{ label: "Project", text: "Build a menu for one real food seller near you. Use free food images from Unsplash. Paste your code below." }],
  },
  {
    id: "9",
    title: "Project 3 - Fashion Designer / Tailor Portfolio",
    objective: "Build a gallery portfolio with prices and a booking form.",
    pidgin: "Tailors in Port Harcourt have plenty of Instagram pictures but no website. Give them one.",
    sellTo: "Tailors and fashion designers in Port Harcourt",
    price: "N30,000 (highest)",
    points: [
      "Instagram-style gallery with 6 styles, each with a price",
      "Tap a picture to see it big (lightbox)",
      '"Book Measurement" form that sends to WhatsApp',
    ],
    note: {
      label: "Secret to make money",
      text: 'Tell the tailor: "With a website, you will look like a big boutique and you can charge more."',
    },
    templateName: "Tailor Portfolio",
    template: tailorTemplate,
    tasks: [{ label: "Project", text: "Customise this portfolio for a real tailor. Paste your code below." }],
  },
  {
    id: "10",
    title: "How to Collect Money & Get Your First Client",
    objective: "Not coding - this is the MONEY skill.",
    pidgin: "Code alone will not feed you. How you sell it is what brings the money.",
    points: [
      'Where to find clients: Facebook groups like "Port Harcourt Vendors", Instagram, and walking around your street.',
      'What to say: "Aunty, I have already built a website for your shop. If you like it, pay me N15k and I will add your phone number and name. If you don\'t like it, don\'t pay."',
      'How to collect: Use Opay, PalmPay or bank transfer. Never accept "I will pay you later".',
      "Free hosting: Put the website online for free with Netlify, Vercel or Lovable.",
      'Certificate: Unlock "CodeRise Level 2 Graduate - Freelancer".',
    ],
    tasks: [
      {
        label: "Final Task for Level 2",
        text: "Paste the link to the first website you sold, even if it was for your mum's shop.",
      },
    ],
  },
];

export const level3: TemplateLesson[] = [
  {
    id: "11",
    title: "Python - Why Python Is the Money Language",
    objective: "Understand why Python is the easiest way to earn dollars.",
    pidgin:
      "If HTML is the bricklayer, Python is the chief engineer. International clients pay Python developers around $20 per hour just to automate boring work.",
    points: [
      "You don't need a big laptop. Python can run on your phone with the Pydroid 3 app.",
      "3 Python jobs posted on Upwork every day: removing duplicate names from Excel (a N50k job), collecting phone numbers from Google Maps, and building a bot that sends WhatsApp messages automatically.",
      "Install: go to the Play Store and download Pydroid 3. Or use the Python playground below.",
    ],
    python: `print("My name is Emeka, I am a dollar earner")
money = 20000
dollar = money / 1500
print(f"My N20k is \${dollar} dollars")`,
    tasks: [{ label: "Task", text: "Calculate how much a N100k website is in dollars. Paste your code and answer below." }],
  },
  {
    id: "12",
    title: "Python for Market People - Automate Excel",
    objective: "Clean up messy business lists and add up sales in seconds.",
    pidgin:
      "A school on D-Line has 500 student names mixed up. With Python you can clean the list in 2 minutes.",
    sellTo: "Business owners, schools and churches struggling with Excel",
    price: "$20 - $50 on Upwork / N30k in Port Harcourt",
    python: `# Clean a shop sales list
sales = ["jollof - 2500", "jollof - 2500", "afang - 3000", "jollof - 2500"]
clean_sales = list(set(sales))  # removes duplicates
print(clean_sales)

# Calculate total money
total = 0
for s in [2500, 2500, 3000]:
    total = total + s
print(f"Total sales: N{total}")`,
    tasks: [
      {
        label: "Project",
        text: "Ask a provision store for their sales book, type 20 lines into Python and calculate the total. Show them - they will pay you. Paste your code below.",
      },
    ],
  },
  {
    id: "13",
    title: "Web Scraping - Find Customers for Businesses",
    objective: "Use Python to pull live data from the internet.",
    pidgin:
      "You can help someone collect the phone numbers of every restaurant on Instagram automatically. Instead of searching for 3 days, you do it in 5 minutes.",
    sellTo: "Real estate agents and car dealers in Port Harcourt who need leads",
    price: "$30 - $100",
    note: {
      label: "Note",
      text: "In the playground we use open_url instead of the requests library, because the playground runs inside your browser. On Pydroid or a laptop you can use requests.get(url).json(). A daily exchange rate checker alone is a $20 gig.",
    },
    python: `import json
from pyodide.http import open_url

# Get the price of the dollar
url = "https://api.exchangerate-api.com/v4/latest/USD"
data = json.loads(open_url(url).read())
print(f"Today Naira to Dollar: N{data['rates']['NGN']}")`,
    tasks: [
      {
        label: "Project",
        text: 'Build a "Dollar to Naira Checker" website using the Lesson 7 template plus this Python code. Sell it to Aboki FX traders. Paste your code below.',
      },
    ],
  },
  {
    id: "14",
    title: "Build an Upwork Profile Clients Will Love",
    objective: "No code. Pure packaging.",
    pidgin: "Clients judge you by your profile before they see your code. Follow this template.",
    points: [
      'Title: "Nigerian Web Developer | I Build Websites for Small Businesses in 24 Hours"',
      "Photo: Wear a white shirt in front of a clean background.",
      'Description: "I help small business owners get more customers with fast, mobile-friendly websites. I have built 15+ websites for businesses in Nigeria. I can build your business website, connect WhatsApp orders and Google Maps in 24 hours. Let\'s talk."',
      "Portfolio: Use your Lesson 7, 8 and 9 projects - that's 3 portfolio pieces already!",
      "First 3 jobs trick: Bid only $10 to earn 5-star reviews. After 3 reviews, raise your price to $50.",
    ],
    tasks: [{ label: "Task", text: "Create your Upwork account TODAY. Paste the link to your profile below." }],
  },
  {
    id: "15",
    title: "Final Boss - Your $100 Agency",
    objective: "Become a CEO.",
    pidgin:
      "You can code and you can sell. Now hire other young people. Take a job for $100, pay your teammate N20k to do it, and keep the rest.",
    points: [
      "Team: Invite 2 friends from CodeRise Level 2 - one handles design, one handles code.",
      'Offer: "We Build Websites for African Businesses - $99 in 48 Hours"',
      "Where to post: Facebook groups for US small businesses, LinkedIn and Twitter.",
      "Payment: Use Grey.co or Geegpay to collect dollars - they give you a free US bank account.",
      'Certificate: "CodeRise Level 3 Graduate - Dollar Earner. Certified to teach Level 1 students and earn 20% referral."',
    ],
    tasks: [
      {
        label: "Final Graduation Project",
        text: "As a team, build one website for a real NGO in Port Harcourt for FREE, film a testimonial, and use it to win dollar clients. Paste the website link and testimonial link below.",
      },
    ],
  },
];

export const allLessons: TemplateLesson[] = [...level1, ...level2, ...level3];
export const levels: Record<1 | 2 | 3, TemplateLesson[]> = { 1: level1, 2: level2, 3: level3 };
export const levelOf = (id: string): 1 | 2 | 3 =>
  level3.some((l) => l.id === id) ? 3 : level2.some((l) => l.id === id) ? 2 : 1;

export const extraQuizzes: Record<string, Quiz> = {
  "4": { question: "What does CSS do?", options: ["Styles how a page looks", "Stores data", "Sends emails"], answer: 0 },
  "5": { question: "Which language makes a page react to clicks?", options: ["HTML", "JavaScript", "CSS"], answer: 1 },
  "6": { question: "Which section should a business website show first?", options: ["The footer", "A hero with what the business does", "The privacy policy"], answer: 1 },
  "7": { question: "What helps customers find a POS shop quickly?", options: ["A Google Maps location", "A long history page", "Background music"], answer: 0 },
  "8": { question: "Best way for food customers to order on the site?", options: ["Fax", "A WhatsApp order button", "Post office"], answer: 1 },
  "9": { question: "What matters most on a tailor's portfolio?", options: ["A gallery of past work", "Lots of text", "Ads"], answer: 0 },
  "10": { question: "When should you ask a client for payment?", options: ["Never", "Agree a deposit before you start", "Only after a year"], answer: 1 },
  "11": { question: "Why is Python popular for earning online?", options: ["It is simple and used for automation and data", "It only makes games", "It is very old"], answer: 0 },
  "12": { question: "What can Python do with Excel files?", options: ["Nothing", "Read and update them automatically", "Print them only"], answer: 1 },
  "13": { question: "Web scraping means...", options: ["Collecting information from websites with code", "Deleting websites", "Painting a website"], answer: 0 },
  "14": { question: "What makes an Upwork profile stand out?", options: ["A clear title and real portfolio work", "No photo", "Copying others"], answer: 0 },
  "15": { question: "Why build a free site for an NGO first?", options: ["To get a real testimonial and portfolio piece", "Because money is bad", "No reason"], answer: 0 },
};
