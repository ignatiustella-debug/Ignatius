type Msg = { role: "user" | "assistant"; content: string };

export async function askTutor({ data }: { data: { lesson: string; messages: Msg[] } }): Promise<{ reply: string }> {
  try {
    const res = await fetch("/api/tutor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (res.ok) {
      const json = await res.json();
      if (json.reply) return json;
    }
  } catch {
    // Network or server offline; proceed to fallback response
  }

  const lastMsg = data.messages[data.messages.length - 1]?.content.toLowerCase() || "";
  const lesson = data.lesson;

  if (lastMsg.includes("hint") || lastMsg.includes("task")) {
    return {
      reply: "Here's a hint: Break the task into small steps! Start with the basic structure first, test that it runs using the RUN button, and then tweak the styling or details. You've got this! 🔥",
    };
  }

  if (lastMsg.includes("example") || lastMsg.includes("show me")) {
    return {
      reply: "Think of an everyday example: in code, a variable is like a labelled box (e.g. price = 5000), a condition is an if-gate, and a function is an action you can reuse. Try modifying the code editor above and press RUN!",
    };
  }

  if (lastMsg.includes("simply") || lastMsg.includes("explain")) {
    return {
      reply: "Let's make it super simple: Code is just clear instructions for the computer. Like following a recipe step-by-step, the browser reads your code top to bottom. Read the explanation in the card above and give the code editor a spin!",
    };
  }

  return {
    reply: `Great question! Focus on the key objective of this lesson. Keep your code clean, check for matching closing tags or brackets, and test it in the playground. Keep pushing! 💪`,
  };
}
