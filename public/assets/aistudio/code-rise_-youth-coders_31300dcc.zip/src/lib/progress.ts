import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useProgress(userId: string | undefined) {
  return useQuery({
    queryKey: ["progress", userId],
    enabled: !!userId,
    queryFn: async () => {
      const localProgressKey = `coderise_progress_${userId}`;
      const localSubsKey = `coderise_subs_${userId}`;

      let localCompleted: string[] = [];
      try {
        localCompleted = JSON.parse(localStorage.getItem(localProgressKey) || "[]");
      } catch {
        localCompleted = [];
      }

      let localSubs: { lesson_id: string; kind: string; content: string }[] = [];
      try {
        localSubs = JSON.parse(localStorage.getItem(localSubsKey) || "[]");
      } catch {
        localSubs = [];
      }

      // Also try syncing from Supabase if reachable
      try {
        const [p, s] = await Promise.all([
          supabase.from("lesson_progress").select("lesson_id"),
          supabase.from("submissions").select("lesson_id, kind, content"),
        ]);
        if (!p.error && p.data) {
          p.data.forEach((r) => {
            if (!localCompleted.includes(r.lesson_id)) {
              localCompleted.push(r.lesson_id);
            }
          });
        }
        if (!s.error && s.data) {
          s.data.forEach((sub) => {
            if (!localSubs.some((x) => x.lesson_id === sub.lesson_id && x.kind === sub.kind)) {
              localSubs.push(sub);
            }
          });
        }
      } catch {
        // Fall back gracefully to local storage
      }

      const completed = new Set(localCompleted);
      const subs = localSubs;
      const hasFinal = (id: string) => subs.some((x) => x.lesson_id === id && x.kind === "final");
      const level2 = hasFinal("5");
      const level3 = hasFinal("10");
      const graduated = hasFinal("15");
      return { completed, subs, level2, level3, graduated };
    },
  });
}

export function useMarkComplete(userId: string | undefined) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (lessonId: string) => {
      if (!userId) return;

      // 1. Always save in localStorage so it never fails
      const localProgressKey = `coderise_progress_${userId}`;
      let list: string[] = [];
      try {
        list = JSON.parse(localStorage.getItem(localProgressKey) || "[]");
      } catch {
        list = [];
      }
      if (!list.includes(lessonId)) {
        list.push(lessonId);
        localStorage.setItem(localProgressKey, JSON.stringify(list));
      }

      // 2. Try remote Supabase upsert
      try {
        await supabase
          .from("lesson_progress")
          .upsert({ user_id: userId, lesson_id: lessonId }, { onConflict: "user_id,lesson_id" });
      } catch {
        // Remote error or RLS policy: local progress is safe
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["progress", userId] }),
  });
}

export function useSubmit(userId: string | undefined) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (v: { lessonId: string; kind: string; content: string }) => {
      if (!userId) return;

      // 1. Always save in localStorage
      const localSubsKey = `coderise_subs_${userId}`;
      let subs: { lesson_id: string; kind: string; content: string }[] = [];
      try {
        subs = JSON.parse(localStorage.getItem(localSubsKey) || "[]");
      } catch {
        subs = [];
      }
      const existingIdx = subs.findIndex((x) => x.lesson_id === v.lessonId && x.kind === v.kind);
      if (existingIdx >= 0) {
        subs[existingIdx] = { lesson_id: v.lessonId, kind: v.kind, content: v.content };
      } else {
        subs.push({ lesson_id: v.lessonId, kind: v.kind, content: v.content });
      }
      localStorage.setItem(localSubsKey, JSON.stringify(subs));

      // Also mark as complete
      const localProgressKey = `coderise_progress_${userId}`;
      let list: string[] = [];
      try {
        list = JSON.parse(localStorage.getItem(localProgressKey) || "[]");
      } catch {
        list = [];
      }
      if (!list.includes(v.lessonId)) {
        list.push(v.lessonId);
        localStorage.setItem(localProgressKey, JSON.stringify(list));
      }

      // 2. Try remote Supabase upsert
      try {
        await supabase.from("submissions").upsert(
          { user_id: userId, lesson_id: v.lessonId, kind: v.kind, content: v.content, updated_at: new Date().toISOString() },
          { onConflict: "user_id,lesson_id,kind" },
        );
        await supabase
          .from("lesson_progress")
          .upsert({ user_id: userId, lesson_id: v.lessonId }, { onConflict: "user_id,lesson_id" });
      } catch {
        // Remote error: local submission is safe
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["progress", userId] }),
  });
}
