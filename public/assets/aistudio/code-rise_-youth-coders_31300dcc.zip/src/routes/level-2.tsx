import { createFileRoute } from "@tanstack/react-router";
import { LevelPage } from "@/components/LevelPage";

export const Route = createFileRoute("/level-2")({
  head: () => ({
    meta: [
      { title: "Level 2: Build & Sell — Code Rise" },
      { name: "description", content: "Five lessons with real website templates you can sell to local businesses for N10k - N30k." },
      { property: "og:title", content: "Level 2: Build & Sell — Code Rise" },
      { property: "og:description", content: "Build and sell real business websites." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <LevelPage level={2} />,
});
