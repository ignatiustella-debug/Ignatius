import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { allLessons, extraQuizzes, levelOf, levels } from "@/lib/lessons";
import { TutorVideo } from "@/components/TutorVideo";
import { LessonTutor } from "@/components/LessonTutor";
import { PythonPlayground } from "@/components/PythonPlayground";
import { useAuth } from "@/hooks/useAuth";
import { useMarkComplete, useProgress, useSubmit } from "@/lib/progress";

function kindFor(label: string) {
  return label.startsWith("Final") ? "final" : label.toLowerCase();
}

function SubmitBox({ lessonId, label }: { lessonId: string; label: string }) {
  const { user, ready } = useAuth();
  const { data } = useProgress(user?.id);
  const submit = useSubmit(user?.id);
  const kind = kindFor(label);
  const saved = data?.subs.find((s) => s.lesson_id === lessonId && s.kind === kind)?.content;
  const [text, setText] = useState("");
  const [ok, setOk] = useState(false);
  useEffect(() => {
    if (saved) setText(saved);
  }, [saved]);

  if (!ready) return null;
  if (!user)
    return (
      <Link to="/auth" className="mt-3 inline-block rounded-md bg-card px-4 py-2 text-sm font-semibold text-card-foreground">
        Sign in to submit your work
      </Link>
    );
  const isFinal = kind === "final";
  return (
    <div className="mt-3">
      <textarea
        value={text}
        onChange={(e) => { setText(e.target.value); setOk(false); }}
        placeholder={label === "Task" ? "I want to learn coding to..." : "Paste your code here..."}
        rows={isFinal ? 8 : 4}
        className="w-full rounded-md bg-card p-3 font-mono text-sm text-card-foreground outline-none"
      />
      <button
        disabled={!text.trim() || submit.isPending}
        onClick={() => submit.mutate({ lessonId, kind, content: text }, { onSuccess: () => setOk(true) })}
        className="mt-2 rounded-md bg-secondary px-4 py-2 font-bold text-secondary-foreground disabled:opacity-50"
      >
        {submit.isPending ? "Saving..." : saved ? "Update submission" : "Submit"}
      </button>
      {ok && <span className="ml-3 font-semibold">{isFinal ? finalMsg(lessonId) : "Saved ✓"}</span>}
      {isFinal && saved && lessonId === "5" && <Link to="/level-2" className="ml-3 underline">Go to Level 2 →</Link>}
      {isFinal && saved && lessonId === "10" && <Link to="/level-3" className="ml-3 underline">Go to Level 3 →</Link>}
      {submit.error && <p className="mt-2 text-sm">Could not save. Try again.</p>}
    </div>
  );
}

function CompleteButton({ lessonId }: { lessonId: string }) {
  const { user } = useAuth();
  const { data } = useProgress(user?.id);
  const mark = useMarkComplete(user?.id);
  if (!user) return null;
  const done = data?.completed.has(lessonId);
  return (
    <button
      disabled={done || mark.isPending}
      onClick={() => mark.mutate(lessonId)}
      className="card-pop mt-8 w-full bg-secondary px-5 py-3 font-semibold"
    >
      {done ? "✓ Lesson completed" : "Mark lesson as done"}
    </button>
  );
}

export const Route = createFileRoute("/learn/$lessonId")({
  loader: ({ params }) => {
    const lesson = allLessons.find((l) => l.id === params.lessonId);
    if (!lesson) throw notFound();
    return lesson;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `Lesson ${loaderData?.id}: ${loaderData?.title} — Code Rise` },
      { name: "description", content: loaderData?.objective ?? "" },
      { property: "og:title", content: `Lesson ${loaderData?.id}: ${loaderData?.title}` },
      { property: "og:description", content: loaderData?.objective ?? "" },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  notFoundComponent: () => (
    <main className="p-10 text-center">
      Lesson not found. <Link to="/learn" className="text-primary underline">Back to lessons</Link>
    </main>
  ),
  component: LessonPage,
});

function LessonPage() {
  const lesson = Route.useLoaderData();
  const n = Number(lesson.id);
  const level = levelOf(lesson.id);
  const list = levels[level];
  const idx = list.findIndex((l) => l.id === lesson.id);
  const backTo = level === 1 ? "/learn" : level === 2 ? "/level-2" : "/level-3";
  const { user, ready } = useAuth();
  const { data, isLoading } = useProgress(user?.id);
  const unlocked = level === 1 || (level === 2 ? !!data?.level2 : !!data?.level3);
  if (level > 1 && (!ready || (user && isLoading))) return <main className="p-10 text-center">Loading...</main>;
  if (!unlocked)
    return (
      <main className="mx-auto max-w-xl p-10 text-center">
        <p className="text-3xl font-bold">🔒 Lesson {lesson.id} is locked</p>
        <p className="mt-3 text-muted-foreground">Finish Level {level - 1} to unlock Level {level}.</p>
        <Link to={backTo} className="card-pop mt-6 inline-block bg-primary px-5 py-3 font-semibold text-primary-foreground">See Level {level}</Link>
      </main>
    );
  return (
    <main className="mx-auto min-h-screen max-w-3xl px-5 py-8" key={lesson.id}>
      <Link to={backTo} className="font-mono text-sm text-accent">{`< Level ${level}`}</Link>
      <p className="mt-6 font-mono text-sm text-primary">LEVEL {level} · LESSON {lesson.id}</p>
      <h1 className="mt-2 text-3xl font-bold md:text-5xl">{lesson.title}</h1>

      <div className="card-pop mt-6 bg-secondary p-5">
        <p className="font-mono text-xs uppercase">Objective</p>
        <p className="mt-1 font-semibold">{lesson.objective}</p>
      </div>

      <TutorVideo title={lesson.title} slides={[lesson.objective, lesson.pidgin, ...(lesson.points ?? [])]} />
      <ListenButton text={`${lesson.title}. ${lesson.objective}. ${lesson.pidgin} ${(lesson.points ?? []).join(". ")}`} />
      <div className="card-pop mt-5 bg-card p-5">
        <p className="font-mono text-xs uppercase text-accent">Explanation</p>
        <p className="mt-2 text-lg">{lesson.pidgin}</p>
      </div>

      {lesson.points && (
        <ol className="mt-6 space-y-3">
          {lesson.points.map((p, i) => (
            <li key={i} className="flex gap-3"><span className="font-mono text-primary">{i + 1}.</span>{p}</li>
          ))}
        </ol>
      )}

      {lesson.note && (
        <p className="mt-6"><strong>{lesson.note.label}:</strong> {lesson.note.text}</p>
      )}

      {(lesson.sellTo || lesson.price) && (
        <div className="card-pop mt-5 bg-accent p-5 text-accent-foreground">
          {lesson.sellTo && <p><strong>Sell to:</strong> {lesson.sellTo}</p>}
          {lesson.price && <p className="mt-1"><strong>Price:</strong> {lesson.price}</p>}
        </div>
      )}

      {lesson.template && <TemplateBox name={lesson.templateName ?? "Template"} code={lesson.template} />}
      {lesson.code && <CodeEditor initial={lesson.code} />}
      {lesson.python && <PythonPlayground initial={lesson.python} />}
      {(lesson.quiz ?? extraQuizzes[lesson.id]) && <QuizBox quiz={(lesson.quiz ?? extraQuizzes[lesson.id])!} />}

      {lesson.tasks.map((t) => (
        <div key={t.label} className="card-pop mt-6 bg-primary p-5 text-primary-foreground">
          <p className="font-mono text-xs uppercase">{t.label}</p>
          <p className="mt-1 font-semibold">{t.text}</p>
          {t.list && <ol className="mt-2 list-decimal pl-5">{t.list.map((x) => <li key={x}>{x}</li>)}</ol>}
          {t.label !== "Next Level Unlock" && <SubmitBox lessonId={lesson.id} label={t.label} />}
        </div>
      ))}

      <CompleteButton lessonId={lesson.id} />
      <LessonTutor lesson={`Lesson ${lesson.id}: ${lesson.title}. Objective: ${lesson.objective}. ${lesson.pidgin} ${(lesson.points ?? []).join(" ")} Tasks: ${lesson.tasks.map((t) => t.text).join(" ")}`} />

      <div className="mt-10 flex justify-between gap-4">
        {idx > 0 ? <Link to="/learn/$lessonId" params={{ lessonId: String(n - 1) }} className="card-pop bg-card px-5 py-3 font-semibold">← Previous</Link> : <span />}
        {idx < list.length - 1 ? (
          <Link to="/learn/$lessonId" params={{ lessonId: String(n + 1) }} className="card-pop bg-primary px-5 py-3 font-semibold text-primary-foreground">Next lesson →</Link>
        ) : (
          <Link to={backTo} className="card-pop bg-secondary px-5 py-3 font-semibold">Finish Level {level}</Link>
        )}
      </div>
    </main>
  );
}

function finalMsg(id: string) {
  if (id === "5") return "Submitted! Level 2 unlocked 🎉";
  if (id === "10") return "Submitted! You're a Level 2 Graduate and Level 3 is unlocked 🎉";
  return "Submitted! You're a Level 3 Graduate - Dollar Earner 🎓";
}

function TemplateBox({ name, code }: { name: string; code: string }) {
  const [editing, setEditing] = useState(false);
  function preview() {
    const url = URL.createObjectURL(new Blob([code], { type: "text/html" }));
    window.open(url, "_blank");
  }
  function download() {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([code], { type: "text/html" }));
    a.download = name.toLowerCase().replace(/\s+/g, "-") + ".html";
    a.click();
  }
  return (
    <div className="card-pop mt-6 bg-card p-5">
      <p className="font-mono text-xs uppercase text-accent">Website template</p>
      <p className="mt-1 text-xl font-bold">{name}</p>
      <iframe title={name} srcDoc={code} sandbox="allow-scripts allow-modals allow-popups" className="mt-3 h-64 w-full rounded-md border-2 border-foreground bg-card" />
      <div className="mt-3 flex flex-wrap gap-3">
        <button onClick={preview} className="card-pop bg-muted px-4 py-2 font-semibold">👁 Preview</button>
        <button onClick={() => setEditing(true)} className="card-pop bg-primary px-4 py-2 font-semibold text-primary-foreground">✏️ Use This Template</button>
        <button onClick={download} className="card-pop bg-secondary px-4 py-2 font-semibold">⬇ Download Code</button>
      </div>
      {editing && <CodeEditor initial={code} />}
    </div>
  );
}

function CodeEditor({ initial }: { initial: string }) {
  const [code, setCode] = useState(initial);
  const [out, setOut] = useState(initial);
  return (
    <div className="card-pop mt-6 overflow-hidden bg-card">
      <div className="flex items-center justify-between border-b-2 border-foreground bg-foreground px-4 py-2 text-background">
        <span className="font-mono text-xs">code editor</span>
        <button onClick={() => setOut(code)} className="rounded bg-secondary px-4 py-1 text-sm font-bold text-secondary-foreground">RUN ▶</button>
      </div>
      <textarea value={code} onChange={(e) => setCode(e.target.value)} spellCheck={false} rows={Math.min(code.split("\n").length + 1, 24)} className="w-full bg-card p-4 font-mono text-sm outline-none" />
      <iframe title="Result" srcDoc={out} sandbox="allow-scripts allow-modals allow-popups" className="h-56 w-full border-t-2 border-foreground bg-card" />
    </div>
  );
}

function QuizBox({ quiz }: { quiz: { question: string; options: string[]; answer: number } }) {
  const [pick, setPick] = useState<number | null>(null);
  return (
    <div className="card-pop mt-6 bg-card p-5">
      <p className="font-mono text-xs uppercase text-accent">Quiz</p>
      <p className="mt-1 font-semibold">{quiz.question}</p>
      <div className="mt-3 flex flex-wrap gap-3">
        {quiz.options.map((o, i) => (
          <button key={o} onClick={() => setPick(i)} className={`card-pop px-4 py-2 font-mono ${pick === i ? (i === quiz.answer ? "bg-secondary" : "bg-destructive text-destructive-foreground") : "bg-muted"}`}>
            {String.fromCharCode(65 + i)}) {o}
          </button>
        ))}
      </div>
      {pick !== null && <p className="mt-3 font-semibold">{pick === quiz.answer ? "Correct! Well done 🔥" : "Not quite. Try again!"}</p>}
    </div>
  );
}

function ListenButton({ text }: { text: string }) {
  const [on, setOn] = useState(false);
  useEffect(() => () => window.speechSynthesis?.cancel(), []);
  function toggle() {
    const s = window.speechSynthesis;
    if (!s) return;
    if (on) { s.cancel(); setOn(false); return; }
    const u = new SpeechSynthesisUtterance(text.replace(/[`*#<>]/g, " "));
    u.lang = "en-GB";
    u.onend = () => setOn(false);
    s.speak(u);
    setOn(true);
  }
  return (
    <button onClick={toggle} className="card-pop mt-5 bg-accent px-5 py-3 font-semibold text-accent-foreground">
      {on ? "⏹ Stop" : "🔊 Listen to this lesson"}
    </button>
  );
}
