import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { level1 } from "@/lib/lessons";
import { useAuth } from "@/hooks/useAuth";
import { useProgress } from "@/lib/progress";
import { LessonTutor } from "@/components/LessonTutor";
import { Certificate } from "@/components/Certificate";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/learn/")({
  head: () => ({
    meta: [
      { title: "Level 1: Web Basics — Code Rise" },
      { name: "description", content: "Five beginner lessons: coding, the internet, HTML, CSS and JavaScript." },
      { property: "og:title", content: "Level 1: Web Basics — Code Rise" },
      { property: "og:description", content: "Start coding today with five beginner lessons." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LearnIndex,
});

function LearnIndex() {
  const { user, ready, logout } = useAuth();
  const { data } = useProgress(user?.id);
  const qc = useQueryClient();
  const nav = useNavigate();
  const done = data?.completed.size ?? 0;

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await logout();
    nav({ to: "/auth", replace: true });
  }

  return (
    <main className="mx-auto min-h-screen max-w-3xl px-5 py-8">
      <div className="flex items-center justify-between">
        <Link to="/" className="font-display text-2xl font-bold">Code<span className="text-primary">Rise</span></Link>
        {ready && (user ? (
          <button onClick={signOut} className="text-sm underline">Sign out</button>
        ) : (
          <Link to="/auth" className="card-pop bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Sign in</Link>
        ))}
      </div>
      <p className="mt-10 font-mono text-sm text-accent">LEVEL 1</p>
      <h1 className="mt-2 text-4xl font-bold md:text-5xl">Web Basics</h1>
      <p className="mt-3 text-muted-foreground">5 lessons. Finish the final project to unlock Level 2.</p>
      {user ? (
        <div className="mt-5">
          <p className="font-mono text-sm">{done} / {level1.length} lessons done</p>
          <div className="mt-2 h-3 w-full overflow-hidden rounded-full border-2 border-foreground bg-card">
            <div className="h-full bg-primary" style={{ width: `${(done / level1.length) * 100}%` }} />
          </div>
        </div>
      ) : ready ? (
        <p className="card-pop mt-5 bg-secondary p-4 text-sm font-semibold">Sign in to save your progress and submit projects.</p>
      ) : null}
      <ol className="mt-8 space-y-4">
        {level1.map((l) => {
          const isDone = data?.completed.has(l.id);
          return (
            <li key={l.id}>
              <Link to="/learn/$lessonId" params={{ lessonId: l.id }} className="card-pop flex items-center gap-4 bg-card p-5 transition-transform hover:-translate-y-1">
                <span className="font-mono text-2xl text-primary">{isDone ? "✓" : `0${l.id}`}</span>
                <span>
                  <span className="block font-display text-lg font-bold">{l.title}</span>
                  <span className="text-sm text-muted-foreground">{l.objective}</span>
                </span>
              </Link>
            </li>
          );
        })}
        <li>
          <Link to="/level-2" className={`card-pop flex items-center gap-4 p-5 ${data?.level2 ? "bg-secondary" : "bg-muted"}`}>
            <span className="font-mono text-2xl">{data?.level2 ? "🔓" : "🔒"}</span>
            <span className="font-display text-lg font-bold">Level 2: Build & Sell {data?.level2 ? "— Unlocked!" : "— Locked"}</span>
          </Link>
        </li>
        <li>
          <Link to="/level-3" className={`card-pop flex items-center gap-4 p-5 ${data?.level3 ? "bg-secondary" : "bg-muted"}`}>
            <span className="font-mono text-2xl">{data?.level3 ? "🔓" : "🔒"}</span>
            <span className="font-display text-lg font-bold">Level 3: Naira to Dollars {data?.level3 ? "— Unlocked!" : "— Locked"}</span>
          </Link>
        </li>
      </ol>
      {data?.level2 && <Certificate level={1} title="CodeRise Level 1 Graduate - Web Starter" />}
      <LessonTutor lesson={`Level 1: Web Basics. Lessons: ${level1.map((l) => l.title).join("; ")}`} />
    </main>
  );
}
