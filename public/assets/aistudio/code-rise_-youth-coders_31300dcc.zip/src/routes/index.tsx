import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Code Rise — Coding for Youths" },
      { name: "description", content: "Code Rise teaches young people to build websites, games and apps through fun, hands-on coding programs." },
      { property: "og:title", content: "Code Rise — Coding for Youths" },
      { property: "og:description", content: "Hands-on coding programs that help youths build real projects and rise." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const tracks = [
  { age: "Ages 8–11", title: "Code Starters", desc: "Games and animations with block coding. Logic, creativity, confidence.", tone: "bg-secondary" },
  { age: "Ages 12–14", title: "Web Builders", desc: "HTML, CSS and JavaScript. Ship your first real website.", tone: "bg-primary text-primary-foreground" },
  { age: "Ages 15–19", title: "App Makers", desc: "Python, apps and AI basics. Build a portfolio project.", tone: "bg-accent text-accent-foreground" },
];

const steps = ["Pick a track", "Learn with mentors", "Build real projects", "Show it off at Demo Day"];

function Index() {
  return (
    <main className="min-h-screen">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <span className="font-display text-2xl font-bold">Code<span className="text-primary">Rise</span></span>
        <Link to="/auth" className="card-pop bg-secondary px-4 py-2 text-sm font-semibold">Join now</Link>
      </nav>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-10 md:grid-cols-2 md:py-16">
        <div>
          <p className="font-mono text-sm text-accent">{"> hello_world()"}</p>
          <h1 className="mt-3 text-5xl font-bold leading-[1.05] md:text-7xl">
            Young minds. <span className="text-primary">Real code.</span> Big futures.
          </h1>
          <p className="mt-5 max-w-md text-lg text-muted-foreground">
            Code Rise helps youths learn to build websites, games and apps — with mentors who believe in them.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link to="/learn" className="card-pop bg-primary px-6 py-3 font-semibold text-primary-foreground transition-transform hover:-translate-y-1">Start Level 1</Link>
            <a href="#tracks" className="card-pop bg-card px-6 py-3 font-semibold transition-transform hover:-translate-y-1">See programs</a>
          </div>
        </div>
        <img src={hero} alt="Teenagers coding together on laptops" width={1280} height={960} className="card-pop w-full rotate-1 object-cover" />
      </section>

      <section className="border-y-2 border-foreground bg-foreground py-6 text-background">
        <div className="mx-auto grid max-w-6xl grid-cols-3 px-5 text-center">
          {[["1,200+", "Students"], ["80+", "Mentors"], ["300+", "Projects built"]].map(([n, l]) => (
            <div key={l}><div className="font-display text-3xl font-bold text-secondary md:text-4xl">{n}</div><div className="text-sm opacity-80">{l}</div></div>
          ))}
        </div>
      </section>

      <section id="tracks" className="mx-auto max-w-6xl px-5 py-20">
        <h2 className="text-4xl font-bold md:text-5xl">Find your track</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {tracks.map((t) => (
            <div key={t.title} className={`card-pop p-6 ${t.tone}`}>
              <span className="font-mono text-xs uppercase">{t.age}</span>
              <h3 className="mt-3 text-2xl font-bold">{t.title}</h3>
              <p className="mt-2 opacity-90">{t.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-20">
        <h2 className="text-4xl font-bold md:text-5xl">How it works</h2>
        <ol className="mt-10 grid gap-4 md:grid-cols-4">
          {steps.map((s, i) => (
            <li key={s} className="card-pop bg-card p-5">
              <span className="font-mono text-primary">0{i + 1}</span>
              <p className="mt-2 font-display text-xl font-bold">{s}</p>
            </li>
          ))}
        </ol>
      </section>

      <footer className="border-t-2 border-foreground py-6 text-center text-sm text-muted-foreground">© 2026 Code Rise · Coding for youths</footer>
    </main>
  );
}
