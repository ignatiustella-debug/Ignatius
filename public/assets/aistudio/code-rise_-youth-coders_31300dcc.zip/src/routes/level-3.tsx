import { createFileRoute } from "@tanstack/react-router";
import { LevelPage } from "@/components/LevelPage";

export const Route = createFileRoute("/level-3")({
  head: () => ({
    meta: [
      { title: "Level 3: From Naira to Dollars — Code Rise" },
      { name: "description", content: "Learn Python and freelancing to earn dollars on Upwork, with a built-in Python playground." },
      { property: "og:title", content: "Level 3: From Naira to Dollars — Code Rise" },
      { property: "og:description", content: "Python and dollar freelancing for young coders." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <LevelPage level={3} />,
});
