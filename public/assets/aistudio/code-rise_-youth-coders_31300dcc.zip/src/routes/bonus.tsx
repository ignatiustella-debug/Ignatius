import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { LessonTutor } from "@/components/LessonTutor";
import { useAuth } from "@/hooks/useAuth";
import { useProgress } from "@/lib/progress";

export const Route = createFileRoute("/bonus")({
  head: () => ({
    meta: [
      { title: "Free Bonus Class: Build Apps with Lovable — Code Rise" },
      { name: "description", content: "A free graduation class teaching Code Rise graduates how to build apps with Lovable." },
      { property: "og:title", content: "Free Bonus Class: Build Apps with Lovable — Code Rise" },
      { property: "og:description", content: "Graduates learn to build full apps by describing them." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Bonus,
});

const steps = [
  { t: "What is Lovable?", d: "Lovable is an AI app builder. You describe what you want in plain English, and it writes the code for you — pages, buttons, sign-ups, even a database. You already know HTML, CSS, JavaScript and Python, so you will understand what it builds." },
  { t: "Create your account", d: "Go to lovable.dev and sign up for free with Google or email. You get free credits every day to build with." },
  { t: "Write a great first prompt", d: "Be clear and specific. Say who the app is for, what pages it needs, and the style.", ex: "Build a website for Mama Ngozi's Kitchen in Enugu. Add a menu with prices in naira, a WhatsApp order button, and a warm orange design." },
  { t: "Improve it step by step", d: "Ask for one change at a time: 'Make the buttons bigger', 'Add a gallery page', 'Add a contact form'. Small steps give better results than one huge request." },
  { t: "Add real features", d: "Ask Lovable to add sign-in, save data, or take payments. It can connect a backend for you automatically." },
  { t: "Publish and share", d: "Click Publish to get a live link. Send it to your client on WhatsApp. You can also connect their own domain name." },
  { t: "Turn it into money", d: "Use Lovable to build client websites faster. What took you a week in Level 2 can now take an afternoon — so you can serve more clients and earn more." },
];

function Bonus() {
  const { user, ready } = useAuth();
  const { data, isLoading } = useProgress(user?.id);
  const [done, setDone] = useState<Set<number>>(new Set());
  if (!ready || (user && isLoading)) return <main className="p-10 text-center">Loading...</main>;
  if (!data?.graduated)
    return (
      <main className="mx-auto max-w-xl p-10 text-center">
        <p className="text-3xl font-bold">🔒 Bonus class locked</p>
        <p className="mt-3 text-muted-foreground">Finish all three levels to unlock this free class.</p>
        <Link to="/learn" className="card-pop mt-6 inline-block bg-primary px-5 py-3 font-semibold text-primary-foreground">Back to lessons</Link>
      </main>
    );
  const all = done.size === steps.length;
  return (
    <main className="mx-auto min-h-screen max-w-3xl px-5 py-8">
      <Link to="/level-3" className="font-mono text-sm text-accent">{"< Level 3"}</Link>
      <p className="mt-8 font-mono text-sm text-primary">FREE BONUS CLASS</p>
      <h1 className="mt-2 text-4xl font-bold md:text-5xl">🎁 Build apps with Lovable</h1>
      <p className="mt-3 text-muted-foreground">Your graduation gift. Tick each step as you go.</p>
      <ol className="mt-8 space-y-4">
        {steps.map((s, i) => (
          <li key={i} className={`card-pop p-5 ${done.has(i) ? "bg-secondary" : "bg-card"}`}>
            <div className="flex items-start gap-4">
              <span className="font-mono text-2xl text-primary">{done.has(i) ? "✓" : i + 1}</span>
              <div className="flex-1">
                <p className="font-display text-xl font-bold">{s.t}</p>
                <p className="mt-2">{s.d}</p>
                {s.ex && <pre className="mt-3 whitespace-pre-wrap rounded-md border-2 border-foreground bg-muted p-3 font-mono text-sm">{s.ex}</pre>}
                <button
                  onClick={() => setDone((p) => { const n = new Set(p); n.has(i) ? n.delete(i) : n.add(i); return n; })}
                  className="mt-3 text-sm font-semibold underline"
                >{done.has(i) ? "Undo" : "Mark as done"}</button>
              </div>
            </div>
          </li>
        ))}
      </ol>
      <a href="https://lovable.dev" target="_blank" rel="noreferrer" className="card-pop mt-6 inline-block bg-accent px-5 py-3 font-semibold text-accent-foreground">Open Lovable →</a>
      {all && (
        <div className="card-pop mt-10 bg-primary p-8 text-center text-primary-foreground">
          <p className="text-5xl">🏆🎉</p>
          <p className="mt-3 font-display text-3xl font-bold">Congratulations, Code Rise graduate!</p>
          <p className="mt-2">You went from your first line of HTML to building and selling real apps. You finished every level and the bonus class. We are so proud of you — now go build the future!</p>
        </div>
      )}
      <LessonTutor lesson="Bonus class: building apps with Lovable (lovable.dev), an AI app builder where you describe apps in plain English." />
    </main>
  );
}
