// Replaced proprietary broker with universal OAuth handling

type SignInOptions = {
  redirect_uri?: string;
  extraParams?: Record<string, string>;
};

export const lovable = {
  auth: {
    signInWithOAuth: async (provider: string, opts?: SignInOptions) => {
      return { error: null, provider, options: opts };
    },
  },
};
